SONIX — deck assets
===================
11 figures, each as an editable SVG plus a 2x-resolution PNG.

PowerPoint:  Insert > Pictures > This Device > pick the .svg
             then right-click > Convert to Shape to restyle individual parts.
Google Slides / Canva: use the .png (SVG import is unreliable there).

Which figure goes where — see PART C of SONIX_National_Submission_Pack.pdf.

  01_attack_and_defence     Slide 2
  08_differentiators        Slide 2 (bottom third)
  05_corpus_before_after    Slide 2 or 4
  02_pipeline               Slide 3 — primary
  03_integration_api        Slide 3 — secondary
  04_three_shortcuts        Slide 4 — primary
  06_padding_fix_chart      Slide 4 inset / backup
  07_snr_shortcut_chart     Slide 4 inset / backup
  10_deployment_privacy     Slide 5 — pick this OR 11
  11_impact_stakeholders    Slide 5 — alternative
  09_roadmap                Slide 6 (the empty half)

RULE: green / amber / red are reserved for the risk band. If you recolour
these to a deck theme, do not use those three hues anywhere else.
